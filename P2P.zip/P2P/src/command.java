import java.io.*;
import java.util.Scanner;

public class command {
    public static void main(String[] args) throws IOException {
        System.out.println("Please enter the command");
        Scanner sc =  new Scanner(System.in);
        String in= sc.nextLine();
        switch (in){
            case "list-users":
                BufferedWriter writer1 = new BufferedWriter(new FileWriter("/Users/saiasishsamineni/P2P/src/UserInterests.txt"));
                writer1.close();
                    break;
            case "list-geo":
                BufferedReader br = new BufferedReader(new FileReader("portMapping.txt"));
                String line;
                while ((line = br.readLine()) != null) {
                    System.out.println(line);
                }

                break;
            case "status":
                System.out.println("status");
                break;
            default:
                System.out.println("thanks");
        }
    }
}
