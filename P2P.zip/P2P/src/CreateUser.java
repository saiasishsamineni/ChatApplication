import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class CreateUser {

    public static void createUser() throws Exception{
        BufferedReader reader1 = null;
        BufferedReader reader2 = null;
        BufferedReader reader3 = null;
        BufferedWriter writer1 = null;
        BufferedWriter writer2 = null;
        BufferedWriter writer3 = null;
        String strInterests = "";
        try  {
            reader1 = new BufferedReader(new FileReader("/Users/saiasishsamineni/P2P/src/UserInterests.txt"));
            reader2 = new BufferedReader(new FileReader("/Users/saiasishsamineni/P2P/src/UsedPorts.txt"));
            reader3 = new BufferedReader(new FileReader("/Users/saiasishsamineni/P2P/src/portMapping.txt"));
            {
                String line = reader1.readLine();
                if(line != null) {
                    if(line!=null){
                        String tmpUser = line.split(";")[0];
                        List tmpList = new ArrayList();
                        for(String s : line.split(";")[1].split(",")) {
                            tmpList.add(s);
                        }
                        Server.UserInterests.put(tmpUser, tmpList);
                    }

                    while(line !=  null) {
                        line = reader1.readLine();
                        if(line!=null){
                            String tmpUser = line.split(";")[0];
                            List tmpList = new ArrayList();
                            for(String s : line.split(";")[1].split(",")) {
                                tmpList.add(s);
                            }

                            Server.UserInterests.put(tmpUser, tmpList);
                        }
                    }

                }
            }
            {
                String line = reader3.readLine();
                if(line != null) {


                    if(line!=null){
                        String tmpUser = line.split(";")[0];
                        int tmpPort = Integer.parseInt(line.split(";")[1]);
                        Server.portMapping.put(tmpUser, tmpPort);
                    }

                    while(line !=  null) {
                        line = reader3.readLine();
                        if(line!=null){
                            String tmpUser = line.split(";")[0];
                            int tmpPort = Integer.parseInt(line.split(";")[1]);
                            Server.portMapping.put(tmpUser, tmpPort);
                        }
                    }

                }
            }
            {
                String line = reader2.readLine();
                if(line != null) {



                    if(line!=null){
                        Server.UsedPorts.add(line);
                    }

                    while(line !=  null) {
                        line = reader2.readLine();
                        if(line!=null){
                            Server.UsedPorts.add(line);
                        }
                    }


                }
            }
            reader1.close();
            reader2.close();
            reader3.close();
            writer1 = new BufferedWriter(new FileWriter ("/Users/saiasishsamineni/P2P/src/UserInterests.txt"));
            writer2 = new BufferedWriter(new FileWriter ("/Users/saiasishsamineni/P2P/src/UsedPorts.txt"));
            writer3 = new BufferedWriter(new FileWriter ("/Users/saiasishsamineni/P2P/src/portMapping.txt"));
            Scanner sc=new Scanner(System.in);
            System.out.print("Enter the your name ");
            String UserName =sc.next();
            List interestList = new ArrayList();
            System.out.print("Enter your Interestwith , seperation ");
            String interestString =sc.next();
            strInterests = interestString;
            String strInterest[] = interestString.split(",");
            for(String interest : strInterest)
            {
                interestList.add(interest);
            }
            if(!Server.UserInterests.containsKey(UserName)) {
                Server.UserInterests.put(UserName,interestList);
            }
            else {
                System.out.print("User Already Exists Please enter different User ");
                UserName =sc.next();
                while(!UserName.equals("Exit")) {
                    if(!Server.UserInterests.containsKey(UserName)) {
                        Server.UserInterests.put(UserName,interestList);
                    }
                }
            }
            Random random = new Random();
            int	Portnumber = random.nextInt(1000);
            System.out.println("UsedPorts : "+Server.UsedPorts);
            while(Server.UsedPorts != null && Server.UsedPorts.contains(random))
            {
                Portnumber = random.nextInt(1000);
            }
            Server.UsedPorts.add(Portnumber);
            for(Object tempPort : Server.UsedPorts) {
                writer2.write(tempPort + "\n");
            }
            for(String userKey : Server.UserInterests.keySet()  ) {
                writer1.write(userKey+";"+strInterests+"\n");
            }
            String matchFound = "N";
            for(String userKey : Server.UserInterests.keySet()  ) {
                List TempInterestList = Server.UserInterests.get(userKey);
                for(Object usrInterest : TempInterestList ) {
                    if(interestList.contains((String)usrInterest)) {
                        if(Server.portMapping.containsKey(userKey)) {
                            int userGroupPort = (int)Server.portMapping.get(userKey);

                            final int finalPort = userGroupPort;

                            new Thread(()-> {
                                try {
                                    Client.startChat(finalPort);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }).start();
                            Server.portMapping.put(UserName, finalPort);
                            matchFound = "Y";
                            break;

                        }
                    }
                }
                if(matchFound == "Y") {
                    break;
                }
            }
            if(matchFound.equals("N")) {
                final String finalUserName = UserName;
                final int finalPort = Portnumber;
                new Thread(()-> {
                    try {
                        Server.startServer(finalUserName,finalPort);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }).start();
                Server.portMapping.put(UserName, Portnumber);

            }
            for(String userKey : Server.portMapping.keySet()  ) {
                writer3.write(userKey+";"+Server.portMapping.get(userKey)+"\n");
            }
            writer1.close();
            writer2.close();
            writer3.close();
        }
        catch(Exception e) {
            e.printStackTrace();
        }

    }

    public static void main(String args[])throws Exception{
        createUser();
    }
}
