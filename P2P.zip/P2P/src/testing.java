import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class testing {

    public static void main(String[] args) throws IOException {
        BufferedReader reader1 = null;
        reader1 = new BufferedReader(new FileReader("/Users/saiasishsamineni/P2P/src/UserInterests.txt"));
        String line = reader1.readLine();
        System.out.println(line);
        while(line !=  null) {
            line = reader1.readLine();
            System.out.println(line);

        }
        reader1.close();
        BufferedWriter writer1 = null;
        BufferedWriter writer2 = null;
        BufferedWriter writer3 = null;
        writer1 = new BufferedWriter(new FileWriter ("/Users/saiasishsamineni/P2P/src/UserInterests.txt"));
        writer2 = new BufferedWriter(new FileWriter ("/Users/saiasishsamineni/P2P/src/UsedPorts.txt"));
        writer3 = new BufferedWriter(new FileWriter ("/Users/saiasishsamineni/P2P/src/portMapping.txt"));
        writer1.close();
        writer2.close();
        writer3.close();
    }

}
