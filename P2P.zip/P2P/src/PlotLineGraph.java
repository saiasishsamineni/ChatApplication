import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.*;
import java.util.Map;

public class PlotLineGraph extends JFrame {

    private static final long serialVersionUID = 1L;
    static DefaultCategoryDataset dataset = new DefaultCategoryDataset();
    public PlotLineGraph(String title) {
        super(title);
        // Create chart
        JFreeChart chart = ChartFactory.createLineChart(
                "Peer 2 Peer Perfomance Graph", // Chart title
                "String Sent via Socket", // X-Axis Label
                "Bytes", // Y-Axis Label
                this.dataset
        );

        ChartPanel panel = new ChartPanel(chart);
        setContentPane(panel);
    }

    private static DefaultCategoryDataset createDataset(Map java7Array,Map java8Array,Map writeCharsArray,Map writeUTFArray) {

        String series1 = "Java 7";
        String series2 = "Java 8";
        String series3 = "WriteBytes";
        String series4 = "WriteUTF";

        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        for(Object str : java7Array.keySet()) {
            dataset.addValue((Number) java7Array.get(str), series1, (String)str);
        }
        for(Object str : java8Array.keySet()) {
            dataset.addValue((Number) java8Array.get(str), series2, (String)str);
        }
        for(Object str : writeCharsArray.keySet()) {
            dataset.addValue((Number) writeCharsArray.get(str), series3, (String)str);
        }
        for(Object str : writeUTFArray.keySet()) {
            dataset.addValue((Number) writeUTFArray.get(str), series4, (String)str);
        }
        return dataset;
    }

    public static void Plot(Map java7Array,Map java8Array,Map writeCharsArray,Map writeUTFArray) {
        try {
            DefaultCategoryDataset objDefaultCategoryDataset= createDataset(java7Array,java8Array,writeCharsArray,writeUTFArray);
            dataset = objDefaultCategoryDataset;
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        SwingUtilities.invokeLater(() -> {
            PlotLineGraph example = new PlotLineGraph("Peer 2 Peer Perfomance Graph");
            example.setAlwaysOnTop(true);
            example.pack();
            example.setSize(600, 400);
            example.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            example.setVisible(true);
        });
    }
}  