import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
class Server{
    public volatile static List UsedPorts = new ArrayList();
    public volatile static Map<String,List> UserInterests= new HashMap<String,List>();
    public volatile static	Map<String,Integer>  portMapping = new HashMap<String,Integer>();

    public static void startServer(String UserName,int SocketPort) throws Exception{

        ServerSocket ss=new ServerSocket(SocketPort);
        Socket s=ss.accept();
        DataInputStream din=new DataInputStream(s.getInputStream());
        DataOutputStream dout=new DataOutputStream(s.getOutputStream());
//BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        Map java7Array = new HashMap();
        Map java8Array = new HashMap();
        Map writeCharsArray = new HashMap();
        Map writeUTFArray = new HashMap();
        String str="",str2="";
        while(!str.equals("stop")){

            str=din.readUTF();
            System.out.println("client says: "+str);
            java7Array.put(str,8 * (int) ((((str.length()) * 2) + 45) / 8));
            java8Array.put(str,8 * (int) ((((str.length()) * 2) + 45) / 8) - 8);
            writeCharsArray.put(str,(str.getBytes("UTF-16")).length*2);
            writeUTFArray.put(str,(str.getBytes("UTF-8")).length*2);
            System.out.println("Send Message to Client");
            str2=(new BufferedReader(new InputStreamReader(System.in))).readLine();
            java7Array.put(str2,8 * (int) ((((str2.length()) * 2) + 45) / 8));
            java8Array.put(str2,8 * (int) ((((str2.length()) * 2) + 45) / 8) - 8);
            writeCharsArray.put(str2,(str2.getBytes("UTF-16")).length*2);
            writeUTFArray.put(str2,(str2.getBytes("UTF-8")).length*2);
            dout.writeUTF(str2);
            dout.flush();
        }
        din.close();
        s.close();
        ss.close();
        PlotLineGraph.Plot(java7Array,java8Array,writeCharsArray,writeUTFArray);
    }

}